    
    %% Low pass filter
    V_filtered = lowpass(V,0.005,0.1);
    subplot(4,1,3);
    plot(V_filtered) 
    title('Low pass filtered signal')
    