   
    %% Fourier transform to filtered signal
    V_ff = abs(fft(V_filtered));
    subplot(4,1,4);
    plot(V_ff)
    title('Fourier transform of filtered signal');
