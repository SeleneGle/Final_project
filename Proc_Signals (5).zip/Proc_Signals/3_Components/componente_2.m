close all; clear variables; clc;
  
 %% Calculate Fast Fourier Transform for original signal
    V_f = abs(fft(V));
    subplot(4,1,2);
    plot(V_f) 
    title('Fourier transform of Original signal')
    