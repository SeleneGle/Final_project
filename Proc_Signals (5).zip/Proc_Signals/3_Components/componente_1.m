close all; clear variables; clc;

%% Read data
    n = 1;
    filename=sprintf('motor_%d.xlsx', n);
    T = readtable(filename);  % read the data
    V=T.Voltage_1(1:1000,1);
    figure;
    subplot(4,1,1);
    plot(V)    
    title('Original signal')
    